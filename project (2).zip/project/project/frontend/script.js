// Sample data for tasks
let tasks = [
  { id: 1, title: "Task 1", description: "Description for Task 1", dueDate: "2024-05-12" },
  { id: 2, title: "Task 2", description: "Description for Task 2", dueDate: "2024-05-15" }
];

// Function to display tasks
function displayTasks() {
  const taskList = document.getElementById("taskList");
  taskList.innerHTML = "";
  tasks.forEach(task => {
      const taskDiv = document.createElement("div");
      taskDiv.classList.add("task");
      taskDiv.innerHTML = `
          <h3>${task.title}</h3>
          <p>Description: ${task.description}</p>
          <p>Due Date: ${task.dueDate}</p>
          <button class="viewDetailsButton" data-task-id="${task.id}">View Details</button>
          <button class="deleteTaskButton" data-task-id="${task.id}">Delete</button>
      `;
      taskList.appendChild(taskDiv);
  });
}

// Function to show add task form
function showAddTaskForm() {
  document.getElementById("addTaskForm").style.display = "block";
}

// Function to hide add task form
function hideAddTaskForm() {
  document.getElementById("addTaskForm").style.display = "none";
}

// Function to show task details modal
function showTaskDetails(taskId) {
  const task = tasks.find(t => t.id === taskId);
  const taskDetailsDiv = document.getElementById("taskDetails");
  taskDetailsDiv.innerHTML = `
      <h3>${task.title}</h3>
      <p>Description: ${task.description}</p>
      <p>Due Date: ${task.dueDate}</p>
  `;
  document.getElementById("taskDetailsModal").style.display = "block";
}

// Function to hide task details modal
function hideTaskDetails() {
  document.getElementById("taskDetailsModal").style.display = "none";
}

// Function to delete a task
function deleteTask(taskId) {
  // Find the index of the task with the given taskId
  const index = tasks.findIndex(task => task.id === taskId);
  // Remove the task from the tasks array if found
  if (index !== -1) {
      tasks.splice(index, 1);
      // Update the UI to reflect the deletion
      displayTasks();
  }
}

// Event listener to handle task deletion
document.addEventListener("click", function(event) {
  if (event.target.classList.contains("deleteTaskButton")) {
      const taskId = parseInt(event.target.getAttribute("data-task-id"));
      deleteTask(taskId);
  }
});

// Event listeners
document.getElementById("addTaskButton").addEventListener("click", showAddTaskForm);

document.querySelector(".modal .close").addEventListener("click", hideAddTaskForm);

document.getElementById("saveTaskButton").addEventListener("click", function() {
  const title = document.getElementById("title").value;
  const description = document.getElementById("description").value;
  const dueDate = document.getElementById("dueDate").value;
  const newTask = {
      id: tasks.length + 1,
      title: title,
      description: description,
      dueDate: dueDate
  };
  tasks.push(newTask);
  displayTasks();
  hideAddTaskForm();
});

document.addEventListener("click", function(event) {
  if (event.target.classList.contains("viewDetailsButton")) {
      const taskId = parseInt(event.target.getAttribute("data-task-id"));
      showTaskDetails(taskId);
  }
});

// Display initial tasks
displayTasks();
